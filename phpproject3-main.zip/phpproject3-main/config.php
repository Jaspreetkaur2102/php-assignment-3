<?php

$conn = mysqli_connect('localhost','root','','university_registration') or die('connection failed');

?>